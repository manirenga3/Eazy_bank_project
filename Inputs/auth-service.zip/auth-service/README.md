# eazy-auth-service
eazy bank jwt auth-service POC
